/****************************************************************************
** Meta object code from reading C++ file 'testpage.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../The_Playbook/testpage.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'testpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TestPage_t {
    const uint offsetsAndSize[44];
    char stringdata0[222];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_TestPage_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_TestPage_t qt_meta_stringdata_TestPage = {
    {
QT_MOC_LITERAL(0, 8), // "TestPage"
QT_MOC_LITERAL(9, 10), // "BackSignal"
QT_MOC_LITERAL(20, 0), // ""
QT_MOC_LITERAL(21, 11), // "RefreshTest"
QT_MOC_LITERAL(33, 10), // "SendAnswer"
QT_MOC_LITERAL(44, 3), // "ans"
QT_MOC_LITERAL(48, 21), // "on_backButton_clicked"
QT_MOC_LITERAL(70, 15), // "DisplayTestPlay"
QT_MOC_LITERAL(86, 5), // "Play*"
QT_MOC_LITERAL(92, 1), // "p"
QT_MOC_LITERAL(94, 10), // "SetOption1"
QT_MOC_LITERAL(105, 11), // "std::string"
QT_MOC_LITERAL(117, 7), // "option1"
QT_MOC_LITERAL(125, 10), // "SetOption2"
QT_MOC_LITERAL(136, 7), // "option2"
QT_MOC_LITERAL(144, 10), // "SetOption3"
QT_MOC_LITERAL(155, 7), // "option3"
QT_MOC_LITERAL(163, 10), // "SetOption4"
QT_MOC_LITERAL(174, 7), // "option4"
QT_MOC_LITERAL(182, 9), // "GetResult"
QT_MOC_LITERAL(192, 6), // "result"
QT_MOC_LITERAL(199, 22) // "on_checkButton_clicked"

    },
    "TestPage\0BackSignal\0\0RefreshTest\0"
    "SendAnswer\0ans\0on_backButton_clicked\0"
    "DisplayTestPlay\0Play*\0p\0SetOption1\0"
    "std::string\0option1\0SetOption2\0option2\0"
    "SetOption3\0option3\0SetOption4\0option4\0"
    "GetResult\0result\0on_checkButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TestPage[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x06,    1 /* Public */,
       3,    0,   81,    2, 0x06,    2 /* Public */,
       4,    1,   82,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       6,    0,   85,    2, 0x08,    5 /* Private */,
       7,    1,   86,    2, 0x08,    6 /* Private */,
      10,    1,   89,    2, 0x08,    8 /* Private */,
      13,    1,   92,    2, 0x08,   10 /* Private */,
      15,    1,   95,    2, 0x08,   12 /* Private */,
      17,    1,   98,    2, 0x08,   14 /* Private */,
      19,    1,  101,    2, 0x08,   16 /* Private */,
      21,    0,  104,    2, 0x08,   18 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 11,   14,
    QMetaType::Void, 0x80000000 | 11,   16,
    QMetaType::Void, 0x80000000 | 11,   18,
    QMetaType::Void, 0x80000000 | 11,   20,
    QMetaType::Void,

       0        // eod
};

void TestPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TestPage *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->BackSignal(); break;
        case 1: _t->RefreshTest(); break;
        case 2: _t->SendAnswer((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_backButton_clicked(); break;
        case 4: _t->DisplayTestPlay((*reinterpret_cast< Play*(*)>(_a[1]))); break;
        case 5: _t->SetOption1((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        case 6: _t->SetOption2((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        case 7: _t->SetOption3((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        case 8: _t->SetOption4((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        case 9: _t->GetResult((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        case 10: _t->on_checkButton_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TestPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TestPage::BackSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TestPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TestPage::RefreshTest)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TestPage::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TestPage::SendAnswer)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject TestPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_TestPage.offsetsAndSize,
    qt_meta_data_TestPage,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_TestPage_t
, QtPrivate::TypeAndForceComplete<TestPage, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Play *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *TestPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TestPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TestPage.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int TestPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void TestPage::BackSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void TestPage::RefreshTest()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void TestPage::SendAnswer(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
