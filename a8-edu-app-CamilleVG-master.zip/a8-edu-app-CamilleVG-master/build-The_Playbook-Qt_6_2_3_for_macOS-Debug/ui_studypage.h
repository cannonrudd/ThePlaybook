/********************************************************************************
** Form generated from reading UI file 'studypage.ui'
**
** Created by: Qt User Interface Compiler version 6.2.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDYPAGE_H
#define UI_STUDYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StudyPage
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QPushButton *backButton;
    QFrame *line;
    QPushButton *leftButton;
    QPushButton *rightButton;
    QLabel *playNameLabel;
    QLabel *playsLabel;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *playLayout;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *StudyPage)
    {
        if (StudyPage->objectName().isEmpty())
            StudyPage->setObjectName(QString::fromUtf8("StudyPage"));
        StudyPage->resize(1250, 800);
        StudyPage->setMinimumSize(QSize(1250, 800));
        centralwidget = new QWidget(StudyPage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(460, 0, 321, 71));
        QFont font;
        font.setPointSize(50);
        label->setFont(font);
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName(QString::fromUtf8("backButton"));
        backButton->setGeometry(QRect(20, 20, 81, 31));
        QFont font1;
        backButton->setFont(font1);
        backButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(-30, 60, 1281, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        leftButton = new QPushButton(centralwidget);
        leftButton->setObjectName(QString::fromUtf8("leftButton"));
        leftButton->setGeometry(QRect(70, 230, 111, 351));
        QFont font2;
        font2.setPointSize(80);
        leftButton->setFont(font2);
        leftButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        rightButton = new QPushButton(centralwidget);
        rightButton->setObjectName(QString::fromUtf8("rightButton"));
        rightButton->setGeometry(QRect(1070, 230, 111, 351));
        rightButton->setFont(font2);
        rightButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        playNameLabel = new QLabel(centralwidget);
        playNameLabel->setObjectName(QString::fromUtf8("playNameLabel"));
        playNameLabel->setGeometry(QRect(290, 80, 631, 31));
        QFont font3;
        font3.setPointSize(25);
        playNameLabel->setFont(font3);
        playNameLabel->setAlignment(Qt::AlignCenter);
        playsLabel = new QLabel(centralwidget);
        playsLabel->setObjectName(QString::fromUtf8("playsLabel"));
        playsLabel->setGeometry(QRect(540, 710, 151, 16));
        QFont font4;
        font4.setPointSize(18);
        playsLabel->setFont(font4);
        playsLabel->setAlignment(Qt::AlignCenter);
        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(230, 120, 791, 581));
        playLayout = new QVBoxLayout(verticalLayoutWidget_2);
        playLayout->setObjectName(QString::fromUtf8("playLayout"));
        playLayout->setContentsMargins(0, 0, 0, 0);
        StudyPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(StudyPage);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1250, 21));
        StudyPage->setMenuBar(menubar);
        statusbar = new QStatusBar(StudyPage);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        StudyPage->setStatusBar(statusbar);

        retranslateUi(StudyPage);

        QMetaObject::connectSlotsByName(StudyPage);
    } // setupUi

    void retranslateUi(QMainWindow *StudyPage)
    {
        StudyPage->setWindowTitle(QCoreApplication::translate("StudyPage", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("StudyPage", "STUDY PAGE", nullptr));
        backButton->setText(QCoreApplication::translate("StudyPage", "Back", nullptr));
        leftButton->setText(QCoreApplication::translate("StudyPage", "<", nullptr));
        rightButton->setText(QCoreApplication::translate("StudyPage", ">", nullptr));
        playNameLabel->setText(QCoreApplication::translate("StudyPage", "Playname", nullptr));
        playsLabel->setText(QCoreApplication::translate("StudyPage", "Play x of x", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StudyPage: public Ui_StudyPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDYPAGE_H
