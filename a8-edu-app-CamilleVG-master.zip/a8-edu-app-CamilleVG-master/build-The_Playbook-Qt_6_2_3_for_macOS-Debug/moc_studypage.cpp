/****************************************************************************
** Meta object code from reading C++ file 'studypage.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../The_Playbook/studypage.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'studypage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_StudyPage_t {
    const uint offsetsAndSize[30];
    char stringdata0[195];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_StudyPage_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_StudyPage_t qt_meta_stringdata_StudyPage = {
    {
QT_MOC_LITERAL(0, 9), // "StudyPage"
QT_MOC_LITERAL(10, 10), // "BackSignal"
QT_MOC_LITERAL(21, 0), // ""
QT_MOC_LITERAL(22, 13), // "NextStudyPlay"
QT_MOC_LITERAL(36, 13), // "PrevStudyPlay"
QT_MOC_LITERAL(50, 12), // "RefreshStudy"
QT_MOC_LITERAL(63, 21), // "on_backButton_clicked"
QT_MOC_LITERAL(85, 16), // "DisplayStudyPlay"
QT_MOC_LITERAL(102, 5), // "Play*"
QT_MOC_LITERAL(108, 1), // "p"
QT_MOC_LITERAL(110, 21), // "on_leftButton_clicked"
QT_MOC_LITERAL(132, 22), // "on_rightButton_clicked"
QT_MOC_LITERAL(155, 17), // "UpdateNumberLabel"
QT_MOC_LITERAL(173, 11), // "std::string"
QT_MOC_LITERAL(185, 9) // "labelText"

    },
    "StudyPage\0BackSignal\0\0NextStudyPlay\0"
    "PrevStudyPlay\0RefreshStudy\0"
    "on_backButton_clicked\0DisplayStudyPlay\0"
    "Play*\0p\0on_leftButton_clicked\0"
    "on_rightButton_clicked\0UpdateNumberLabel\0"
    "std::string\0labelText"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_StudyPage[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x06,    1 /* Public */,
       3,    0,   69,    2, 0x06,    2 /* Public */,
       4,    0,   70,    2, 0x06,    3 /* Public */,
       5,    0,   71,    2, 0x06,    4 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       6,    0,   72,    2, 0x08,    5 /* Private */,
       7,    1,   73,    2, 0x08,    6 /* Private */,
      10,    0,   76,    2, 0x08,    8 /* Private */,
      11,    0,   77,    2, 0x08,    9 /* Private */,
      12,    1,   78,    2, 0x08,   10 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 13,   14,

       0        // eod
};

void StudyPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StudyPage *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->BackSignal(); break;
        case 1: _t->NextStudyPlay(); break;
        case 2: _t->PrevStudyPlay(); break;
        case 3: _t->RefreshStudy(); break;
        case 4: _t->on_backButton_clicked(); break;
        case 5: _t->DisplayStudyPlay((*reinterpret_cast< Play*(*)>(_a[1]))); break;
        case 6: _t->on_leftButton_clicked(); break;
        case 7: _t->on_rightButton_clicked(); break;
        case 8: _t->UpdateNumberLabel((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (StudyPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StudyPage::BackSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (StudyPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StudyPage::NextStudyPlay)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (StudyPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StudyPage::PrevStudyPlay)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (StudyPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StudyPage::RefreshStudy)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject StudyPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_StudyPage.offsetsAndSize,
    qt_meta_data_StudyPage,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_StudyPage_t
, QtPrivate::TypeAndForceComplete<StudyPage, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Play *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>


>,
    nullptr
} };


const QMetaObject *StudyPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StudyPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_StudyPage.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int StudyPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void StudyPage::BackSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void StudyPage::NextStudyPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void StudyPage::PrevStudyPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void StudyPage::RefreshStudy()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
