/********************************************************************************
** Form generated from reading UI file 'createpage.ui'
**
** Created by: Qt User Interface Compiler version 6.2.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEPAGE_H
#define UI_CREATEPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CreatePage
{
public:
    QWidget *centralwidget;
    QPushButton *backButton;
    QLabel *createpageLabel;
    QPushButton *passButton;
    QPushButton *runButton;
    QScrollArea *playsScrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *routeLayout;
    QFrame *line;
    QScrollArea *formationsScrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *formationsLayout;
    QPushButton *iButton;
    QLabel *iLabel;
    QPushButton *goalLineButton;
    QLabel *goalLineLabel;
    QPushButton *wishboneButton;
    QLabel *wishboneLabel;
    QPushButton *proSetButton;
    QLabel *proSetLabel;
    QPushButton *spreadButton;
    QLabel *spreadLabel;
    QPushButton *singleBackButton;
    QLabel *singleBackLabel;
    QPushButton *shotgunButton;
    QLabel *shotgunLabel;
    QLabel *formationLabel;
    QPushButton *flipButton;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayoutCenter;
    QLabel *playsLabel;
    QLabel *playnameLabel;
    QTextEdit *textEdit;
    QPushButton *clearButton;
    QPushButton *prevButton;
    QPushButton *nextButton;
    QPushButton *hotButton;

    void setupUi(QMainWindow *CreatePage)
    {
        if (CreatePage->objectName().isEmpty())
            CreatePage->setObjectName(QString::fromUtf8("CreatePage"));
        CreatePage->resize(1250, 800);
        CreatePage->setMinimumSize(QSize(1250, 800));
        centralwidget = new QWidget(CreatePage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName(QString::fromUtf8("backButton"));
        backButton->setGeometry(QRect(10, 20, 91, 31));
        QFont font;
        backButton->setFont(font);
        backButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        createpageLabel = new QLabel(centralwidget);
        createpageLabel->setObjectName(QString::fromUtf8("createpageLabel"));
        createpageLabel->setGeometry(QRect(460, 20, 371, 41));
        QFont font1;
        font1.setPointSize(50);
        createpageLabel->setFont(font1);
        createpageLabel->setAlignment(Qt::AlignCenter);
        passButton = new QPushButton(centralwidget);
        passButton->setObjectName(QString::fromUtf8("passButton"));
        passButton->setGeometry(QRect(10, 80, 101, 31));
        passButton->setFont(font);
        passButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        runButton = new QPushButton(centralwidget);
        runButton->setObjectName(QString::fromUtf8("runButton"));
        runButton->setGeometry(QRect(110, 80, 101, 31));
        runButton->setFont(font);
        runButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        playsScrollArea = new QScrollArea(centralwidget);
        playsScrollArea->setObjectName(QString::fromUtf8("playsScrollArea"));
        playsScrollArea->setGeometry(QRect(10, 110, 201, 581));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(playsScrollArea->sizePolicy().hasHeightForWidth());
        playsScrollArea->setSizePolicy(sizePolicy);
        playsScrollArea->setLayoutDirection(Qt::LeftToRight);
        playsScrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 199, 579));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        routeLayout = new QVBoxLayout();
        routeLayout->setObjectName(QString::fromUtf8("routeLayout"));

        verticalLayout_2->addLayout(routeLayout);

        playsScrollArea->setWidget(scrollAreaWidgetContents);
        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(-30, 60, 1281, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        formationsScrollArea = new QScrollArea(centralwidget);
        formationsScrollArea->setObjectName(QString::fromUtf8("formationsScrollArea"));
        formationsScrollArea->setGeometry(QRect(1039, 110, 201, 621));
        sizePolicy.setHeightForWidth(formationsScrollArea->sizePolicy().hasHeightForWidth());
        formationsScrollArea->setSizePolicy(sizePolicy);
        formationsScrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 184, 1165));
        verticalLayout_3 = new QVBoxLayout(scrollAreaWidgetContents_2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        formationsLayout = new QVBoxLayout();
        formationsLayout->setObjectName(QString::fromUtf8("formationsLayout"));
        formationsLayout->setSizeConstraint(QLayout::SetNoConstraint);
        iButton = new QPushButton(scrollAreaWidgetContents_2);
        iButton->setObjectName(QString::fromUtf8("iButton"));
        iButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(iButton);

        iLabel = new QLabel(scrollAreaWidgetContents_2);
        iLabel->setObjectName(QString::fromUtf8("iLabel"));
        iLabel->setFont(font);
        iLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(iLabel);

        goalLineButton = new QPushButton(scrollAreaWidgetContents_2);
        goalLineButton->setObjectName(QString::fromUtf8("goalLineButton"));
        goalLineButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(goalLineButton);

        goalLineLabel = new QLabel(scrollAreaWidgetContents_2);
        goalLineLabel->setObjectName(QString::fromUtf8("goalLineLabel"));
        goalLineLabel->setFont(font);
        goalLineLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(goalLineLabel);

        wishboneButton = new QPushButton(scrollAreaWidgetContents_2);
        wishboneButton->setObjectName(QString::fromUtf8("wishboneButton"));
        wishboneButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(wishboneButton);

        wishboneLabel = new QLabel(scrollAreaWidgetContents_2);
        wishboneLabel->setObjectName(QString::fromUtf8("wishboneLabel"));
        wishboneLabel->setFont(font);
        wishboneLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(wishboneLabel);

        proSetButton = new QPushButton(scrollAreaWidgetContents_2);
        proSetButton->setObjectName(QString::fromUtf8("proSetButton"));
        proSetButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(proSetButton);

        proSetLabel = new QLabel(scrollAreaWidgetContents_2);
        proSetLabel->setObjectName(QString::fromUtf8("proSetLabel"));
        proSetLabel->setFont(font);
        proSetLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(proSetLabel);

        spreadButton = new QPushButton(scrollAreaWidgetContents_2);
        spreadButton->setObjectName(QString::fromUtf8("spreadButton"));
        spreadButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(spreadButton);

        spreadLabel = new QLabel(scrollAreaWidgetContents_2);
        spreadLabel->setObjectName(QString::fromUtf8("spreadLabel"));
        spreadLabel->setFont(font);
        spreadLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(spreadLabel);

        singleBackButton = new QPushButton(scrollAreaWidgetContents_2);
        singleBackButton->setObjectName(QString::fromUtf8("singleBackButton"));
        singleBackButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(singleBackButton);

        singleBackLabel = new QLabel(scrollAreaWidgetContents_2);
        singleBackLabel->setObjectName(QString::fromUtf8("singleBackLabel"));
        singleBackLabel->setFont(font);
        singleBackLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(singleBackLabel);

        shotgunButton = new QPushButton(scrollAreaWidgetContents_2);
        shotgunButton->setObjectName(QString::fromUtf8("shotgunButton"));
        shotgunButton->setMinimumSize(QSize(160, 130));

        formationsLayout->addWidget(shotgunButton);

        shotgunLabel = new QLabel(scrollAreaWidgetContents_2);
        shotgunLabel->setObjectName(QString::fromUtf8("shotgunLabel"));
        shotgunLabel->setFont(font);
        shotgunLabel->setAlignment(Qt::AlignCenter);

        formationsLayout->addWidget(shotgunLabel);


        verticalLayout_3->addLayout(formationsLayout);

        formationsScrollArea->setWidget(scrollAreaWidgetContents_2);
        formationLabel = new QLabel(centralwidget);
        formationLabel->setObjectName(QString::fromUtf8("formationLabel"));
        formationLabel->setGeometry(QRect(1040, 75, 201, 31));
        QFont font2;
        font2.setPointSize(15);
        formationLabel->setFont(font2);
        formationLabel->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        formationLabel->setAlignment(Qt::AlignCenter);
        flipButton = new QPushButton(centralwidget);
        flipButton->setObjectName(QString::fromUtf8("flipButton"));
        flipButton->setGeometry(QRect(20, 700, 101, 31));
        flipButton->setFont(font);
        flipButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(230, 80, 791, 581));
        verticalLayoutCenter = new QVBoxLayout(verticalLayoutWidget);
        verticalLayoutCenter->setObjectName(QString::fromUtf8("verticalLayoutCenter"));
        verticalLayoutCenter->setContentsMargins(0, 0, 0, 0);
        playsLabel = new QLabel(centralwidget);
        playsLabel->setObjectName(QString::fromUtf8("playsLabel"));
        playsLabel->setGeometry(QRect(580, 670, 121, 21));
        QFont font3;
        font3.setPointSize(18);
        playsLabel->setFont(font3);
        playsLabel->setAlignment(Qt::AlignCenter);
        playnameLabel = new QLabel(centralwidget);
        playnameLabel->setObjectName(QString::fromUtf8("playnameLabel"));
        playnameLabel->setGeometry(QRect(490, 700, 131, 31));
        QFont font4;
        font4.setPointSize(20);
        playnameLabel->setFont(font4);
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(620, 700, 261, 31));
        clearButton = new QPushButton(centralwidget);
        clearButton->setObjectName(QString::fromUtf8("clearButton"));
        clearButton->setGeometry(QRect(180, 20, 91, 31));
        clearButton->setFont(font);
        clearButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        prevButton = new QPushButton(centralwidget);
        prevButton->setObjectName(QString::fromUtf8("prevButton"));
        prevButton->setGeometry(QRect(970, 20, 91, 31));
        prevButton->setFont(font);
        prevButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        nextButton = new QPushButton(centralwidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));
        nextButton->setGeometry(QRect(1130, 20, 91, 31));
        nextButton->setFont(font);
        nextButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        hotButton = new QPushButton(centralwidget);
        hotButton->setObjectName(QString::fromUtf8("hotButton"));
        hotButton->setGeometry(QRect(110, 700, 101, 31));
        hotButton->setFont(font);
        hotButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        CreatePage->setCentralWidget(centralwidget);

        retranslateUi(CreatePage);

        QMetaObject::connectSlotsByName(CreatePage);
    } // setupUi

    void retranslateUi(QMainWindow *CreatePage)
    {
        CreatePage->setWindowTitle(QCoreApplication::translate("CreatePage", "MainWindow", nullptr));
        backButton->setText(QCoreApplication::translate("CreatePage", "Back", nullptr));
        createpageLabel->setText(QCoreApplication::translate("CreatePage", "CREATE PAGE", nullptr));
        passButton->setText(QCoreApplication::translate("CreatePage", "Pass", nullptr));
        runButton->setText(QCoreApplication::translate("CreatePage", "Run", nullptr));
        iButton->setText(QString());
        iLabel->setText(QCoreApplication::translate("CreatePage", "I-Formation", nullptr));
        goalLineButton->setText(QString());
        goalLineLabel->setText(QCoreApplication::translate("CreatePage", "Goal Line", nullptr));
        wishboneButton->setText(QString());
        wishboneLabel->setText(QCoreApplication::translate("CreatePage", "Wishbone", nullptr));
        proSetButton->setText(QString());
        proSetLabel->setText(QCoreApplication::translate("CreatePage", "Pro Set", nullptr));
        spreadButton->setText(QString());
        spreadLabel->setText(QCoreApplication::translate("CreatePage", "Spread", nullptr));
        singleBackButton->setText(QString());
        singleBackLabel->setText(QCoreApplication::translate("CreatePage", "Single Back", nullptr));
        shotgunButton->setText(QString());
        shotgunLabel->setText(QCoreApplication::translate("CreatePage", "Shotgun", nullptr));
        formationLabel->setText(QCoreApplication::translate("CreatePage", "Formations", nullptr));
        flipButton->setText(QCoreApplication::translate("CreatePage", "Flip", nullptr));
        playsLabel->setText(QCoreApplication::translate("CreatePage", "Play 1 of 1", nullptr));
        playnameLabel->setText(QCoreApplication::translate("CreatePage", "PLAYNAME:", nullptr));
        clearButton->setText(QCoreApplication::translate("CreatePage", "Clear", nullptr));
        prevButton->setText(QCoreApplication::translate("CreatePage", "Previous", nullptr));
        nextButton->setText(QCoreApplication::translate("CreatePage", "Next", nullptr));
        hotButton->setText(QCoreApplication::translate("CreatePage", "Hot Pass", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CreatePage: public Ui_CreatePage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEPAGE_H
