/****************************************************************************
** Meta object code from reading C++ file 'createpage.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../The_Playbook/createpage.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'createpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CreatePage_t {
    const uint offsetsAndSize[56];
    char stringdata0[473];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_CreatePage_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_CreatePage_t qt_meta_stringdata_CreatePage = {
    {
QT_MOC_LITERAL(0, 10), // "CreatePage"
QT_MOC_LITERAL(11, 10), // "BackSignal"
QT_MOC_LITERAL(22, 0), // ""
QT_MOC_LITERAL(23, 8), // "NextPlay"
QT_MOC_LITERAL(32, 8), // "PrevPlay"
QT_MOC_LITERAL(41, 9), // "StartPlay"
QT_MOC_LITERAL(51, 5), // "Play*"
QT_MOC_LITERAL(57, 1), // "p"
QT_MOC_LITERAL(59, 21), // "on_backButton_clicked"
QT_MOC_LITERAL(81, 21), // "on_passButton_clicked"
QT_MOC_LITERAL(103, 20), // "on_runButton_clicked"
QT_MOC_LITERAL(124, 21), // "on_flipButton_clicked"
QT_MOC_LITERAL(146, 20), // "on_hotButton_clicked"
QT_MOC_LITERAL(167, 18), // "on_iButton_clicked"
QT_MOC_LITERAL(186, 25), // "on_goalLineButton_clicked"
QT_MOC_LITERAL(212, 25), // "on_wishboneButton_clicked"
QT_MOC_LITERAL(238, 24), // "on_shotgunButton_clicked"
QT_MOC_LITERAL(263, 23), // "on_proSetButton_clicked"
QT_MOC_LITERAL(287, 23), // "on_spreadButton_clicked"
QT_MOC_LITERAL(311, 27), // "on_singleBackButton_clicked"
QT_MOC_LITERAL(339, 22), // "on_clearButton_clicked"
QT_MOC_LITERAL(362, 21), // "on_nextButton_clicked"
QT_MOC_LITERAL(384, 21), // "on_prevButton_clicked"
QT_MOC_LITERAL(406, 11), // "DisplayPlay"
QT_MOC_LITERAL(418, 14), // "UpdatePlayName"
QT_MOC_LITERAL(433, 17), // "UpdateNumberLabel"
QT_MOC_LITERAL(451, 11), // "std::string"
QT_MOC_LITERAL(463, 9) // "labelText"

    },
    "CreatePage\0BackSignal\0\0NextPlay\0"
    "PrevPlay\0StartPlay\0Play*\0p\0"
    "on_backButton_clicked\0on_passButton_clicked\0"
    "on_runButton_clicked\0on_flipButton_clicked\0"
    "on_hotButton_clicked\0on_iButton_clicked\0"
    "on_goalLineButton_clicked\0"
    "on_wishboneButton_clicked\0"
    "on_shotgunButton_clicked\0"
    "on_proSetButton_clicked\0on_spreadButton_clicked\0"
    "on_singleBackButton_clicked\0"
    "on_clearButton_clicked\0on_nextButton_clicked\0"
    "on_prevButton_clicked\0DisplayPlay\0"
    "UpdatePlayName\0UpdateNumberLabel\0"
    "std::string\0labelText"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CreatePage[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  146,    2, 0x06,    1 /* Public */,
       3,    0,  147,    2, 0x06,    2 /* Public */,
       4,    0,  148,    2, 0x06,    3 /* Public */,
       5,    1,  149,    2, 0x06,    4 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    0,  152,    2, 0x08,    6 /* Private */,
       9,    0,  153,    2, 0x08,    7 /* Private */,
      10,    0,  154,    2, 0x08,    8 /* Private */,
      11,    0,  155,    2, 0x08,    9 /* Private */,
      12,    0,  156,    2, 0x08,   10 /* Private */,
      13,    0,  157,    2, 0x08,   11 /* Private */,
      14,    0,  158,    2, 0x08,   12 /* Private */,
      15,    0,  159,    2, 0x08,   13 /* Private */,
      16,    0,  160,    2, 0x08,   14 /* Private */,
      17,    0,  161,    2, 0x08,   15 /* Private */,
      18,    0,  162,    2, 0x08,   16 /* Private */,
      19,    0,  163,    2, 0x08,   17 /* Private */,
      20,    0,  164,    2, 0x08,   18 /* Private */,
      21,    0,  165,    2, 0x08,   19 /* Private */,
      22,    0,  166,    2, 0x08,   20 /* Private */,
      23,    1,  167,    2, 0x08,   21 /* Private */,
      24,    0,  170,    2, 0x08,   23 /* Private */,
      25,    1,  171,    2, 0x08,   24 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 26,   27,

       0        // eod
};

void CreatePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CreatePage *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->BackSignal(); break;
        case 1: _t->NextPlay(); break;
        case 2: _t->PrevPlay(); break;
        case 3: _t->StartPlay((*reinterpret_cast< Play*(*)>(_a[1]))); break;
        case 4: _t->on_backButton_clicked(); break;
        case 5: _t->on_passButton_clicked(); break;
        case 6: _t->on_runButton_clicked(); break;
        case 7: _t->on_flipButton_clicked(); break;
        case 8: _t->on_hotButton_clicked(); break;
        case 9: _t->on_iButton_clicked(); break;
        case 10: _t->on_goalLineButton_clicked(); break;
        case 11: _t->on_wishboneButton_clicked(); break;
        case 12: _t->on_shotgunButton_clicked(); break;
        case 13: _t->on_proSetButton_clicked(); break;
        case 14: _t->on_spreadButton_clicked(); break;
        case 15: _t->on_singleBackButton_clicked(); break;
        case 16: _t->on_clearButton_clicked(); break;
        case 17: _t->on_nextButton_clicked(); break;
        case 18: _t->on_prevButton_clicked(); break;
        case 19: _t->DisplayPlay((*reinterpret_cast< Play*(*)>(_a[1]))); break;
        case 20: _t->UpdatePlayName(); break;
        case 21: _t->UpdateNumberLabel((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CreatePage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CreatePage::BackSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CreatePage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CreatePage::NextPlay)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (CreatePage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CreatePage::PrevPlay)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (CreatePage::*)(Play * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CreatePage::StartPlay)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject CreatePage::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CreatePage.offsetsAndSize,
    qt_meta_data_CreatePage,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_CreatePage_t
, QtPrivate::TypeAndForceComplete<CreatePage, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Play *, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Play *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>


>,
    nullptr
} };


const QMetaObject *CreatePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CreatePage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CreatePage.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int CreatePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void CreatePage::BackSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void CreatePage::NextPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void CreatePage::PrevPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void CreatePage::StartPlay(Play * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
