/********************************************************************************
** Form generated from reading UI file 'testpage.ui'
**
** Created by: Qt User Interface Compiler version 6.2.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTPAGE_H
#define UI_TESTPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TestPage
{
public:
    QWidget *centralwidget;
    QLabel *testpageLabel;
    QPushButton *backButton;
    QFrame *line;
    QLabel *questionLabel;
    QGroupBox *buttonGroup;
    QRadioButton *option1;
    QRadioButton *option2;
    QRadioButton *option3;
    QRadioButton *option4;
    QPushButton *checkButton;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *playLayout;
    QLabel *narrationLabel;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *TestPage)
    {
        if (TestPage->objectName().isEmpty())
            TestPage->setObjectName(QString::fromUtf8("TestPage"));
        TestPage->resize(1250, 800);
        TestPage->setMinimumSize(QSize(1250, 800));
        centralwidget = new QWidget(TestPage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        testpageLabel = new QLabel(centralwidget);
        testpageLabel->setObjectName(QString::fromUtf8("testpageLabel"));
        testpageLabel->setGeometry(QRect(520, -10, 281, 81));
        QFont font;
        font.setPointSize(50);
        testpageLabel->setFont(font);
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName(QString::fromUtf8("backButton"));
        backButton->setGeometry(QRect(20, 20, 80, 24));
        backButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(-30, 60, 1281, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        questionLabel = new QLabel(centralwidget);
        questionLabel->setObjectName(QString::fromUtf8("questionLabel"));
        questionLabel->setGeometry(QRect(830, 110, 341, 41));
        QFont font1;
        font1.setPointSize(25);
        questionLabel->setFont(font1);
        buttonGroup = new QGroupBox(centralwidget);
        buttonGroup->setObjectName(QString::fromUtf8("buttonGroup"));
        buttonGroup->setEnabled(true);
        buttonGroup->setGeometry(QRect(830, 160, 371, 351));
        buttonGroup->setTitle(QString::fromUtf8(""));
        buttonGroup->setFlat(true);
        option1 = new QRadioButton(buttonGroup);
        option1->setObjectName(QString::fromUtf8("option1"));
        option1->setGeometry(QRect(0, 20, 411, 81));
        QFont font2;
        option1->setFont(font2);
        option1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 1px solid black;"));
        option1->setCheckable(true);
        option1->setChecked(false);
        option2 = new QRadioButton(buttonGroup);
        option2->setObjectName(QString::fromUtf8("option2"));
        option2->setGeometry(QRect(0, 100, 411, 81));
        option2->setFont(font2);
        option2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 1px solid black;"));
        option3 = new QRadioButton(buttonGroup);
        option3->setObjectName(QString::fromUtf8("option3"));
        option3->setGeometry(QRect(0, 180, 411, 81));
        option3->setFont(font2);
        option3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 1px solid black;"));
        option4 = new QRadioButton(buttonGroup);
        option4->setObjectName(QString::fromUtf8("option4"));
        option4->setGeometry(QRect(0, 260, 411, 81));
        option4->setFont(font2);
        option4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 1px solid black;"));
        checkButton = new QPushButton(centralwidget);
        checkButton->setObjectName(QString::fromUtf8("checkButton"));
        checkButton->setGeometry(QRect(1110, 530, 91, 31));
        checkButton->setFont(font2);
        checkButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 1px solid black;"));
        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(20, 90, 791, 581));
        playLayout = new QVBoxLayout(verticalLayoutWidget_2);
        playLayout->setObjectName(QString::fromUtf8("playLayout"));
        playLayout->setContentsMargins(0, 0, 0, 0);
        narrationLabel = new QLabel(centralwidget);
        narrationLabel->setObjectName(QString::fromUtf8("narrationLabel"));
        narrationLabel->setGeometry(QRect(840, 600, 371, 41));
        TestPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TestPage);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1250, 26));
        TestPage->setMenuBar(menubar);
        statusbar = new QStatusBar(TestPage);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        TestPage->setStatusBar(statusbar);

        retranslateUi(TestPage);

        QMetaObject::connectSlotsByName(TestPage);
    } // setupUi

    void retranslateUi(QMainWindow *TestPage)
    {
        TestPage->setWindowTitle(QCoreApplication::translate("TestPage", "MainWindow", nullptr));
        testpageLabel->setText(QCoreApplication::translate("TestPage", "TEST PAGE", nullptr));
        backButton->setText(QCoreApplication::translate("TestPage", "Back", nullptr));
        questionLabel->setText(QCoreApplication::translate("TestPage", "Which play is this?", nullptr));
        option1->setText(QCoreApplication::translate("TestPage", "Playname 1", nullptr));
        option2->setText(QCoreApplication::translate("TestPage", "Playname 2", nullptr));
        option3->setText(QCoreApplication::translate("TestPage", "Playname 3", nullptr));
        option4->setText(QCoreApplication::translate("TestPage", "Playname 4", nullptr));
        checkButton->setText(QCoreApplication::translate("TestPage", "Submit", nullptr));
        narrationLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class TestPage: public Ui_TestPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTPAGE_H
