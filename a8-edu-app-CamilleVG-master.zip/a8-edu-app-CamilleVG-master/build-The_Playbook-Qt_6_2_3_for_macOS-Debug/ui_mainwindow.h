/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *playbookLabel;
    QPushButton *createButton;
    QPushButton *studyButton;
    QPushButton *testButton;
    QLabel *ballLabel;
    QLabel *background;
    QPushButton *saveButton;
    QPushButton *loadButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1250, 800);
        MainWindow->setMinimumSize(QSize(1250, 800));
        MainWindow->setMaximumSize(QSize(1600, 900));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        playbookLabel = new QLabel(centralwidget);
        playbookLabel->setObjectName(QString::fromUtf8("playbookLabel"));
        playbookLabel->setGeometry(QRect(-80, -70, 1371, 441));
        QFont font;
        font.setFamilies({QString::fromUtf8("BiauKai")});
        font.setPointSize(150);
        playbookLabel->setFont(font);
        playbookLabel->setStyleSheet(QString::fromUtf8("color: black;"));
        playbookLabel->setAlignment(Qt::AlignCenter);
        createButton = new QPushButton(centralwidget);
        createButton->setObjectName(QString::fromUtf8("createButton"));
        createButton->setGeometry(QRect(20, 580, 381, 101));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("BiauKai")});
        font1.setPointSize(50);
        createButton->setFont(font1);
        createButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        studyButton = new QPushButton(centralwidget);
        studyButton->setObjectName(QString::fromUtf8("studyButton"));
        studyButton->setGeometry(QRect(440, 580, 381, 101));
        studyButton->setFont(font1);
        studyButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        testButton = new QPushButton(centralwidget);
        testButton->setObjectName(QString::fromUtf8("testButton"));
        testButton->setGeometry(QRect(850, 580, 331, 101));
        testButton->setFont(font1);
        testButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        ballLabel = new QLabel(centralwidget);
        ballLabel->setObjectName(QString::fromUtf8("ballLabel"));
        ballLabel->setGeometry(QRect(560, 450, 100, 100));
        ballLabel->setPixmap(QPixmap(QString::fromUtf8(":/Images/football.png")));
        ballLabel->setScaledContents(true);
        background = new QLabel(centralwidget);
        background->setObjectName(QString::fromUtf8("background"));
        background->setGeometry(QRect(0, 0, 1251, 771));
        background->setPixmap(QPixmap(QString::fromUtf8(":/Images/FullField.png")));
        background->setScaledContents(true);
        saveButton = new QPushButton(centralwidget);
        saveButton->setObjectName(QString::fromUtf8("saveButton"));
        saveButton->setGeometry(QRect(140, 330, 261, 61));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("BiauKai")});
        font2.setPointSize(30);
        saveButton->setFont(font2);
        saveButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        loadButton = new QPushButton(centralwidget);
        loadButton->setObjectName(QString::fromUtf8("loadButton"));
        loadButton->setGeometry(QRect(850, 330, 261, 61));
        loadButton->setFont(font2);
        loadButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: black;\n"
"border: 2px solid black;"));
        MainWindow->setCentralWidget(centralwidget);
        background->raise();
        createButton->raise();
        studyButton->raise();
        testButton->raise();
        ballLabel->raise();
        playbookLabel->raise();
        saveButton->raise();
        loadButton->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1250, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        playbookLabel->setText(QCoreApplication::translate("MainWindow", "The Playbook", nullptr));
        createButton->setText(QCoreApplication::translate("MainWindow", "Create", nullptr));
        studyButton->setText(QCoreApplication::translate("MainWindow", "Study", nullptr));
        testButton->setText(QCoreApplication::translate("MainWindow", "Test", nullptr));
        ballLabel->setText(QString());
        background->setText(QString());
        saveButton->setText(QCoreApplication::translate("MainWindow", "Save", nullptr));
        loadButton->setText(QCoreApplication::translate("MainWindow", "Load", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
